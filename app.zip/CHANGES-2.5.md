# BlockStreak 2.5 (versionCode 5)
Built on 2.4. NOT compiled here: your GitHub Actions build is the first compile. Send me any red errors.

- Auto screenshots are copied automatically to Downloads/BlockStreak/Auto, or to a folder you choose
  (Profile > Auto screenshots > Save a copy automatically > Choose). "Copy older" copies the ones already taken.
- "Add my screenshots" button in Gallery > Auto (imports your own pictures).
- More reliable detection of Minecraft (checks the foreground app every 8 s with Usage Access; one stray window
  no longer switches capture off for the whole session). First shot after 10-25 s. Never photographs other apps.
- If recording was on and Android forgot the approval, a notification asks you to turn it back on.
- Recording problems are now shown in Profile > Gameplay recording ("Last problem").
- Profile shows the real installed version at the bottom.
- Keep-running-in-background shortcut; Usage Access hint.
- New app icon: flat flame-on-block mark on a dark green gradient, plus a themed (monochrome) icon for Android 13+ and a clean flame glyph for notifications.

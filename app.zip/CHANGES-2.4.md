# BlockStreak 2.4 wired into app.zip (versionCode 4, versionName 2.4)
Applied to your real repo files: new Recorder.kt, Stats.kt, Reminders.kt; new assets/www/index.html;
AndroidManifest (permissions incl. FOREGROUND_SERVICE_MEDIA_PROJECTION, RecService mediaProjection, receivers);
MainActivity (permission chain notif->audio->screen capture, all rec*/rem*/gameStats/shareImage bridge methods,
/recs/ + /recthumb/ with Range handled in shouldInterceptRequest); ShotService (Recorder.begin/end/onInfo).
NOT compiled, NOT run on a device. Your GitHub Actions build is the first compile: send me any red errors.
Notification icon uses ic_launcher_foreground (no monochrome icon exists in this repo).

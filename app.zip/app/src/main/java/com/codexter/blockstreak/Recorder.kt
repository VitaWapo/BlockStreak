package com.codexter.blockstreak

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.webkit.WebResourceResponse
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Records the screen and the game's sound while Minecraft/Flarial is open, finds highlights,
 * and manages clips (thumbnails, trim, share, save to the phone gallery).
 *
 * Highlights are not random: during a session, moments are marked from real signals
 *   - the player taps "Save highlight" in the recording notification
 *   - a loud audio spike (explosions, boss fights, big hits)
 *   - the OCR reader sees an XP level-up, a new biome or a new world day
 * When the session ends, the best moments are cut into short clips. No signals = no highlights.
 */
object Recorder {
    private const val TAG = "Recorder"
    private const val GRACE_MS = 20_000L
    private const val AUDIO_WAIT_MS = 3_000L              // start the muxer without audio if the AAC track hasn't appeared by then
    private const val MIN_FREE_BYTES = 1_000_000_000L     // don't start a recording with less than ~1 GB free
    private const val SAMPLE_RATE = 44_100
    private const val FPS = 30
    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    @Volatile private var current: Session? = null
    private var projCallback: MediaProjection.Callback? = null
    private var pendingEnd: Runnable? = null
    /** Files that are still being written or cut (never listed, trimmed, deleted or pruned until done). */
    private val busy: MutableSet<String> = java.util.Collections.synchronizedSet(HashSet<String>())
    private var lastLevel: Int? = null
    private var lastBiome: String? = null
    private var lastDay: Int? = null

    private val BITRATES = intArrayOf(2_500_000, 4_000_000, 6_000_000) // 720p H.264: low / balanced / high

    private fun prefs(c: Context) = c.getSharedPreferences("rec", Context.MODE_PRIVATE)
    fun dir(c: Context) = File(c.filesDir, "rec").apply { mkdirs() }
    private fun thumbDir(c: Context) = File(dir(c), ".thumbs").apply { mkdirs() }
    private fun side(c: Context, id: String) = File(dir(c), id.removeSuffix(".mp4") + ".json")

    fun hasAudioPermission(c: Context) =
        Build.VERSION.SDK_INT >= 29 &&
            c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun gameOf(pkg: String?): String = when (pkg) {
        "com.mojang.minecraftpe.preview" -> "pre"
        "xyz.flarial.client", "com.flarialmc.flarial_launcher" -> "fl"
        else -> "mc"
    }

    fun state(c: Context): String = JSONObject()
        .put("ready", projection != null).put("recording", current != null)
        .put("quality", prefs(c).getInt("q", 1)).put("keep", prefs(c).getInt("keep", 14))
        .put("audio", prefs(c).getBoolean("audio", true))
        .put("audioOk", hasAudioPermission(c))
        .put("hl", prefs(c).getBoolean("hl", true))
        .toString()

    fun setPrefs(c: Context, quality: Int, keepDays: Int) {
        prefs(c).edit().putInt("q", quality.coerceIn(0, 2)).putInt("keep", keepDays.coerceIn(1, 365)).apply()
    }

    fun setAudio(c: Context, on: Boolean) { prefs(c).edit().putBoolean("audio", on).apply() }
    fun setHighlights(c: Context, on: Boolean) { prefs(c).edit().putBoolean("hl", on).apply() }

    fun hasProjection(): Boolean = projection != null

    /**
     * Keeps the approved projection. `svc` lets us stop the foreground service when the system ends the projection
     * (status-bar chip, screen lock on Android 15, ...), so the "recording is on" notification doesn't linger.
     * The callback must be registered before createVirtualDisplay (Android 14).
     */
    @Synchronized fun attach(p: MediaProjection, svc: Context? = null) {
        if (projection != null) shutdown()          // a re-approval replaces the old projection; never keep two
        projection = p
        val app = svc?.applicationContext
        val cb = object : MediaProjection.Callback() {
            override fun onStop() {
                if (projection !== p) return
                shutdown { app?.let { a -> runCatching { a.stopService(Intent(a, RecService::class.java)) } } }
            }
        }
        projCallback = cb
        p.registerCallback(cb, main)
    }

    /** Call when Minecraft/Flarial comes to the foreground. `pkg` is the foreground package. */
    @Synchronized fun begin(c: Context, pkg: String? = null) {
        pendingEnd?.let { main.removeCallbacks(it) }; pendingEnd = null
        val p = projection ?: return
        if (current != null) return
        val app = c.applicationContext
        prune(app)
        if (dir(app).usableSpace < MIN_FREE_BYTES) {
            main.post { Toast.makeText(app, "Not enough free storage to record", Toast.LENGTH_SHORT).show() }
            return
        }
        lastLevel = null; lastBiome = null; lastDay = null
        val m = app.resources.displayMetrics
        val long = maxOf(m.widthPixels, m.heightPixels); val short = minOf(m.widthPixels, m.heightPixels)
        val w = 1280; val h = (w.toFloat() * short / long / 2f).toInt() * 2
        val f = File(dir(app), SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".mp4")
        val wantAudio = prefs(app).getBoolean("audio", true) && hasAudioPermission(app)
        val s = Session(f, w, h, BITRATES[prefs(app).getInt("q", 1).coerceIn(0, 2)], wantAudio, p, gameOf(pkg),
            prefs(app).getBoolean("hl", true), app)
        busy.add(f.name)
        try {
            val surface = s.prepare()
            val d = display
            if (d == null) {
                display = p.createVirtualDisplay("blockstreak-rec", w, h, m.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null)
            } else {
                d.resize(w, h, m.densityDpi)
                d.surface = surface
            }
            s.start()
            current = s
        } catch (e: SecurityException) {
            // Android 14+: the projection token is dead (already used, or revoked). Drop it so the UI asks again.
            Log.w(TAG, "projection rejected", e)
            s.abort(); f.delete(); busy.remove(f.name)
            shutdown { app.stopService(Intent(app, RecService::class.java)) }
        } catch (e: Exception) {
            Log.w(TAG, "could not start recording", e)
            runCatching { display?.surface = null }
            s.abort(); f.delete(); busy.remove(f.name)
        }
    }

    /** Call when the game leaves the foreground. Stops after a short grace period. */
    @Synchronized fun end() {
        if (current == null) return
        pendingEnd?.let { main.removeCallbacks(it) }
        val job = Runnable { endNow() }
        pendingEnd = job
        main.postDelayed(job, GRACE_MS)
    }

    @Synchronized private fun endNow() {
        pendingEnd = null
        val s = current ?: return
        current = null
        runCatching { display?.surface = null }
        Thread({ s.finish() }, "rec-finish").start()
    }

    /**
     * Ends everything: finishes the current clip, releases the display and stops the projection.
     * The clip is finalised on a worker thread; `onDone` (main thread) runs after that, so the caller can keep the
     * foreground service alive until the MP4 is safely written.
     */
    @Synchronized fun shutdown(onDone: (() -> Unit)? = null) {
        pendingEnd?.let { main.removeCallbacks(it) }; pendingEnd = null
        val s = current; current = null
        runCatching { display?.surface = null }
        runCatching { display?.release() }; display = null
        val p = projection; projection = null
        val cb = projCallback; projCallback = null
        if (p != null) {
            if (cb != null) runCatching { p.unregisterCallback(cb) }   // so stop() doesn't call back into us
            runCatching { p.stop() }
        }
        val done = Runnable { if (onDone != null) main.post { onDone() } }
        if (s == null) done.run() else Thread({ try { s.finish() } finally { done.run() } }, "rec-finish").start()
    }

    /** Marks the current moment as a highlight. reason: manual | loud | level | biome | day. */
    fun mark(reason: String, score: Int) { current?.addMarker(reason, score) }

    /** Feed this from the OCR reader whenever it parses a screenshot. Marks level-ups, new biomes, new days. */
    fun onInfo(day: Int?, level: Int?, biome: String?) {
        if (current == null) return
        if (level != null) { val l = lastLevel; if (l != null && level > l) mark("level", 7); lastLevel = level }
        if (biome != null) { val b = lastBiome; if (b != null && b != biome) mark("biome", 5); lastBiome = biome }
        if (day != null) { val d = lastDay; if (d != null && day > d) mark("day", 4); lastDay = day }
    }

    private fun prune(c: Context) {
        val cutoff = System.currentTimeMillis() - prefs(c).getInt("keep", 14) * 86_400_000L
        val live = current?.file
        dir(c).listFiles { f -> f.extension == "mp4" }?.filter { it.lastModified() < cutoff && it != live && it.name !in busy }?.forEach { remove(c, it.name) }
        dir(c).listFiles { f -> f.extension == "part" }?.filter { it.lastModified() < System.currentTimeMillis() - 3_600_000L }?.forEach { it.delete() }
        dir(c).listFiles { f -> f.extension == "json" }?.forEach { if (!File(dir(c), it.nameWithoutExtension + ".mp4").exists()) it.delete() }
    }

    private fun remove(c: Context, id: String): Boolean {
        val ok = File(dir(c), id).delete()
        side(c, id).delete()
        File(thumbDir(c), id.removeSuffix(".mp4") + ".jpg").delete()
        prefs(c).edit().remove("uri_$id").apply()
        return ok
    }

    fun list(c: Context): String {
        val a = JSONArray()
        val live = current?.file
        dir(c).listFiles { f -> f.extension == "mp4" && f != live && f.length() > 0 && f.name !in busy }
            ?.sortedByDescending { it.lastModified() }?.forEach { f ->
                var dur = 0L; var audio = false
                val readable = runCatching {
                    val mr = MediaMetadataRetriever()
                    try {
                        mr.setDataSource(f.absolutePath)
                        dur = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
                        audio = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
                    } finally { mr.release() }
                }.isSuccess
                if (!readable) return@forEach          // unfinished file left by a crash: not a playable clip
                val meta = runCatching { JSONObject(side(c, f.name).readText()) }.getOrDefault(JSONObject())
                a.put(JSONObject().put("id", f.name).put("t", f.lastModified()).put("b", f.length())
                    .put("d", dur).put("a", audio)
                    .put("g", meta.optString("g", "mc")).put("k", meta.optString("k", "full")).put("r", meta.optString("r", "")))
            }
        return a.toString()
    }

    private fun safe(c: Context, id: String): File? =
        File(dir(c), id).takeIf { it.parentFile == dir(c) && it.extension == "mp4" && it.exists() && it != current?.file && it.name !in busy }

    fun delete(c: Context, id: String): Boolean = safe(c, id)?.let { remove(c, id) } ?: false

    // ---------- phone gallery + sharing ----------

    /** Copies a clip into Movies/BlockStreak (shows in the phone's gallery). Returns its content Uri. */
    private fun toGallery(c: Context, id: String): Uri? {
        val f = safe(c, id) ?: return null
        prefs(c).getString("uri_$id", null)?.let { s ->
            val u = Uri.parse(s)
            if (runCatching { c.contentResolver.openInputStream(u)?.close() }.isSuccess) return u
        }
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "blockstreak-$id")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/BlockStreak")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val u = c.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return null
        return try {
            c.contentResolver.openOutputStream(u)?.use { o -> f.inputStream().use { it.copyTo(o) } }
            if (Build.VERSION.SDK_INT >= 29) {
                c.contentResolver.update(u, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            }
            prefs(c).edit().putString("uri_$id", u.toString()).apply()
            u
        } catch (e: Exception) { c.contentResolver.delete(u, null, null); null }
    }

    fun save(c: Context, id: String): Boolean = toGallery(c, id) != null

    /** Opens the Android share sheet for one clip. */
    fun share(a: Activity, id: String): Boolean {
        val u = toGallery(a, id) ?: return false
        val i = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, u)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        a.runOnUiThread { a.startActivity(Intent.createChooser(i, "Share clip")) }
        return true
    }

    /** Saves a PNG (base64) to Pictures/BlockStreak and opens the share sheet. Used by the weekly recap. */
    fun shareImage(a: Activity, b64: String, name: String): Boolean {
        val bytes = runCatching { Base64.decode(b64, Base64.DEFAULT) }.getOrNull() ?: return false
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BlockStreak")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val u = a.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return false
        try {
            a.contentResolver.openOutputStream(u)?.use { it.write(bytes) }
            if (Build.VERSION.SDK_INT >= 29) {
                a.contentResolver.update(u, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
            }
        } catch (e: Exception) { a.contentResolver.delete(u, null, null); return false }
        val i = Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM, u)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        a.runOnUiThread { a.startActivity(Intent.createChooser(i, "Share recap")) }
        return true
    }

    // ---------- trimming ----------

    /**
     * Cuts [startMs, endMs] out of a clip without re-encoding (fast, no quality loss).
     * The start snaps back to the previous keyframe, so it can begin up to ~1 s early.
     * Returns the id of the result ("" on failure). replace=true overwrites the original.
     */
    fun trim(c: Context, id: String, startMs: Long, endMs: Long, replace: Boolean): String {
        val src = safe(c, id) ?: return ""
        if (endMs - startMs < 1000) return ""
        val base = id.removeSuffix(".mp4")
        val stamp = System.currentTimeMillis() % 100000
        val finalName = if (replace) id else "$base-trim$stamp.mp4"
        val part = File(dir(c), "$base.trim$stamp.part")          // never listed until it is complete
        if (!cut(src, part, startMs, endMs)) { part.delete(); return "" }
        val meta = runCatching { JSONObject(side(c, id).readText()) }.getOrDefault(JSONObject())
        val fin = File(dir(c), finalName)
        if (replace) {
            val t = src.lastModified()
            // rename(2) replaces the original atomically, so a failure leaves the original untouched
            if (!part.renameTo(fin)) { part.delete(); return "" }
            fin.setLastModified(t)
            File(thumbDir(c), "$base.jpg").delete()
            prefs(c).edit().remove("uri_$id").apply()
            runCatching { side(c, id).writeText(meta.toString()) }
        } else {
            runCatching { side(c, finalName).writeText(meta.put("k", "full").toString()) }
            if (!part.renameTo(fin)) { part.delete(); side(c, finalName).delete(); return "" }
        }
        return finalName
    }

    internal fun cut(src: File, dst: File, startMs: Long, endMs: Long): Boolean {
        val ex = MediaExtractor()
        var mux: MediaMuxer? = null
        var started = false
        try {
            ex.setDataSource(src.absolutePath)
            mux = MediaMuxer(dst.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val map = HashMap<Int, Int>()
            var vIdx = -1
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    ex.selectTrack(i); map[i] = mux.addTrack(f)
                    if (mime.startsWith("video/")) vIdx = i
                }
            }
            if (map.isEmpty()) return false
            ex.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            mux.start(); started = true
            val buf = ByteBuffer.allocate(2 shl 20)
            val info = MediaCodec.BufferInfo()
            var t0 = -1L
            var wrote = 0
            while (true) {
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                val t = ex.sampleTime
                if (t > endMs * 1000) break
                val ti = ex.sampleTrackIndex
                if (t0 < 0) {
                    // After seekTo the video starts at the previous keyframe but audio starts right at the seek point.
                    // Time zero is the first video keyframe; audio before it is dropped so A/V stay aligned.
                    if (vIdx >= 0 && ti != vIdx) { ex.advance(); continue }
                    t0 = t
                }
                val track = map[ti]
                if (track != null && t >= t0) {
                    info.set(0, size, t - t0, ex.sampleFlags)
                    mux.writeSampleData(track, buf, info); wrote++
                }
                ex.advance()
            }
            return wrote > 0
        } catch (e: Exception) {
            return false
        } finally {
            runCatching { ex.release() }
            runCatching { if (started) mux?.stop() }
            runCatching { mux?.release() }
        }
    }

    // ---------- thumbnails + serving to the WebView ----------

    private fun thumbFor(c: Context, id: String): File? {
        val f = safe(c, id) ?: return null
        val t = File(thumbDir(c), id.removeSuffix(".mp4") + ".jpg")
        if (t.exists() && t.length() > 0) return t
        val mr = MediaMetadataRetriever()
        return try {
            mr.setDataSource(f.absolutePath)
            val dur = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
            val bmp = mr.getFrameAtTime(dur * 250, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return null
            val w = 480; val h = maxOf(2, bmp.height * w / bmp.width)
            val sc = Bitmap.createScaledBitmap(bmp, w, h, true)
            t.outputStream().use { sc.compress(Bitmap.CompressFormat.JPEG, 80, it) }
            t
        } catch (e: Exception) { null } finally { runCatching { mr.release() } }
    }

    /** Serves /recthumb/<id> (JPEG poster frame, cached). Call from shouldInterceptRequest. */
    fun serveThumb(c: Context, id: String): WebResourceResponse? {
        val t = thumbFor(c, id) ?: return null
        return WebResourceResponse("image/jpeg", null, 200, "OK",
            mapOf("Cache-Control" to "max-age=86400", "Access-Control-Allow-Origin" to "*"), FileInputStream(t))
    }

    /** Serves /recs/<id> with HTTP Range support so the <video> tag can seek. `range` = request header. */
    fun serve(c: Context, id: String, range: String?): WebResourceResponse? {
        val f = safe(c, id) ?: return null
        val len = f.length()
        var start = 0L; var end = len - 1
        var partial = false
        if (range != null && range.startsWith("bytes=")) {
            val parts = range.removePrefix("bytes=").split("-")
            val s = parts.getOrNull(0)?.toLongOrNull()
            val e = parts.getOrNull(1)?.toLongOrNull()
            if (s != null) { start = s; if (e != null) end = minOf(e, len - 1); partial = true }
            else if (e != null) { start = maxOf(0L, len - e); partial = true }
        }
        if (start >= len || start > end) {
            return WebResourceResponse("video/mp4", null, 416, "Range Not Satisfiable",
                mapOf("Content-Range" to "bytes */$len"), ByteArrayInputStream(ByteArray(0)))
        }
        val count = end - start + 1
        val from = start
        val stream: InputStream = object : InputStream() {
            private val raf = RandomAccessFile(f, "r").also { it.seek(from) }
            private var left = count
            override fun read(): Int { val b = ByteArray(1); return if (read(b, 0, 1) <= 0) -1 else b[0].toInt() and 0xff }
            override fun read(b: ByteArray, off: Int, n: Int): Int {
                if (left <= 0) return -1
                val r = raf.read(b, off, minOf(n.toLong(), left).toInt())
                if (r > 0) left -= r
                return r
            }
            override fun close() { runCatching { raf.close() } }
        }
        val headers = mutableMapOf(
            "Accept-Ranges" to "bytes", "Content-Length" to count.toString(),
            "Access-Control-Allow-Origin" to "*")
        if (partial) headers["Content-Range"] = "bytes $start-$end/$len"
        return WebResourceResponse("video/mp4", null, if (partial) 206 else 200,
            if (partial) "Partial Content" else "OK", headers, stream)
    }

    private class Marker(val tMs: Long, val reason: String, val score: Int)

    /** One recording: video encoder + optional audio encoder feeding a single MP4 muxer. */
    private class Session(
        val file: File, val w: Int, val h: Int, val bitrate: Int,
        val wantAudio: Boolean, val projection: MediaProjection, val game: String,
        val wantHighlights: Boolean, val app: Context
    ) {
        private val lock = Object()
        private var muxer: MediaMuxer? = null
        private var vCodec: MediaCodec? = null
        private var aCodec: MediaCodec? = null
        private var audioRec: AudioRecord? = null
        private var vTrack = -1; private var aTrack = -1
        private var muxStarted = false; private var muxFailed = false
        @Volatile private var finished = false
        private var tracksExpected = 1
        private var vTrackAtMs = 0L
        private var t0Us = 0L
        private class Pending(val video: Boolean, val data: ByteArray, val pts: Long, val flags: Int)
        private val pending = ArrayList<Pending>()
        private var pendingBytes = 0
        private val startedAt = System.currentTimeMillis()
        @Volatile private var stopping = false
        private var vThread: Thread? = null
        private var aReadThread: Thread? = null
        private var aDrainThread: Thread? = null
        private val markers = ArrayList<Marker>()
        private var lastLoudMs = -100_000L

        fun addMarker(reason: String, score: Int) {
            val t = (System.nanoTime() / 1000 - t0Us) / 1000
            if (t < 0) return
            synchronized(markers) { markers.add(Marker(t, reason, score)) }
            if (reason == "manual") Handler(Looper.getMainLooper()).post {
                Toast.makeText(app, "Highlight saved", Toast.LENGTH_SHORT).show()
            }
        }

        fun prepare(): android.view.Surface {
            // Timeline origin. Must be set BEFORE the virtual display gets the surface, otherwise the first frames
            // would carry timestamps earlier than t0 (negative after subtracting) and had to be clamped.
            t0Us = System.nanoTime() / 1000
            val vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1) // 1 s keyframes: trims start within ~1 s
                // A surface encoder only emits output when the screen changes. Repeating the last frame keeps a static
                // screen (loading, pause) producing output, so the muxer can start and the timeline keeps moving.
                setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 500_000L)
            }
            val vc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            vCodec = vc
            vc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = vc.createInputSurface()

            if (wantAudio && Build.VERSION.SDK_INT >= 29) {
                try { prepareAudio() } catch (e: Exception) {
                    runCatching { audioRec?.release() }; audioRec = null
                    runCatching { aCodec?.release() }; aCodec = null
                }
            }
            tracksExpected = if (aCodec != null && audioRec != null) 2 else 1
            muxer = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            return surface
        }

        @android.annotation.SuppressLint("MissingPermission")
        private fun prepareAudio() {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(cfg)
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(maxOf(min * 4, 32 * 1024))
                .build()
            if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); throw IllegalStateException("audio") }
            audioRec = rec
            val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 2).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16 * 1024)
            }
            val ac = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            ac.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            aCodec = ac
        }

        fun start() {
            vCodec!!.start()
            vThread = Thread({ drain(vCodec!!, true) }, "rec-video").also { it.start() }
            val ac = aCodec; val rec = audioRec
            if (ac != null && rec != null) {
                ac.start(); rec.startRecording()
                aReadThread = Thread({ readAudio(ac, rec) }, "rec-audio-in").also { it.start() }
                aDrainThread = Thread({ drain(ac, false) }, "rec-audio-out").also { it.start() }
            }
        }

        /** Pushes captured PCM into the AAC encoder and watches the loudness for highlight moments. */
        private fun readAudio(ac: MediaCodec, rec: AudioRecord) {
            val buf = ByteArray(8 * 1024)
            var samples = 0L
            var ema = 0.0
            var baseUs = System.nanoTime() / 1000 - t0Us      // audio timeline origin, relative to t0 (same as video)
            while (!stopping) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) { if (n < 0) break else continue }
                // Audio time normally comes from the sample count. If capture stalled (nothing playing, or we were
                // too slow and AudioRecord dropped data) the wall clock runs ahead of it; move the audio timeline
                // forward so sound stays in sync with the video (leaves a silent gap instead of drifting early).
                val nowUs = System.nanoTime() / 1000 - t0Us
                val chunkStartUs = nowUs - (n / 4) * 1_000_000L / SAMPLE_RATE
                val expectedUs = baseUs + samples * 1_000_000L / SAMPLE_RATE
                if (chunkStartUs - expectedUs > 80_000L) baseUs += chunkStartUs - expectedUs
                // loudness (RMS of 16-bit samples) vs a slow average of the last ~30 s
                var sum = 0.0; var cnt = 0
                var k = 0
                while (k + 1 < n) { val v = ((buf[k + 1].toInt() shl 8) or (buf[k].toInt() and 0xff)).toShort().toInt(); sum += v.toDouble() * v; cnt++; k += 4 }
                val rms = if (cnt > 0) sqrt(sum / cnt) else 0.0
                val nowMs = nowUs / 1000
                val floor = maxOf(ema, 800.0)                 // sound starting after silence is not a "big moment"
                if (nowMs > 15_000 && rms > 2500 && rms > floor * 3.2 && nowMs - lastLoudMs > 12_000) {
                    lastLoudMs = nowMs
                    addMarker("loud", (4 + (rms / floor).toInt() / 2).coerceAtMost(9))
                }
                ema = if (ema == 0.0) rms else ema + (rms - ema) * 0.0015
                var off = 0
                while (off + 4 <= n && !stopping) {
                    val i = ac.dequeueInputBuffer(10_000)
                    if (i < 0) continue
                    val ib = ac.getInputBuffer(i) ?: continue
                    ib.clear()
                    val chunk = minOf(ib.remaining(), n - off) and 3.inv()   // whole stereo frames only
                    ib.put(buf, off, chunk)
                    val pts = baseUs + samples * 1_000_000L / SAMPLE_RATE
                    ac.queueInputBuffer(i, 0, chunk, pts, 0)
                    samples += chunk / 4
                    off += chunk
                }
            }
            while (true) {
                val i = ac.dequeueInputBuffer(10_000)
                if (i >= 0) {
                    ac.queueInputBuffer(i, 0, 0, baseUs + samples * 1_000_000L / SAMPLE_RATE, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    break
                }
                if (aDrainThread?.isAlive != true) break
            }
        }

        private fun drain(codec: MediaCodec, video: Boolean) {
            val info = MediaCodec.BufferInfo()
            var lastPts = -1L
            var first = true
            try {
                while (true) {
                    val i = codec.dequeueOutputBuffer(info, 10_000)
                    when {
                        i == MediaCodec.INFO_TRY_AGAIN_LATER -> { if (video) startWithoutAudioIfStuck() }
                        i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> addTrack(codec.outputFormat, video)
                        i >= 0 -> {
                            val data = codec.getOutputBuffer(i)
                            val config = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                            if (data != null && info.size > 0 && !config) {
                                var pts = if (video) info.presentationTimeUs - t0Us else info.presentationTimeUs
                                if (first) { first = false; Log.i(TAG, (if (video) "first video" else "first audio") + " pts(rel t0)=" + pts / 1000 + " ms") }
                                if (pts < 0) pts = 0
                                if (pts <= lastPts) pts = lastPts + 1
                                lastPts = pts
                                info.presentationTimeUs = pts
                                data.position(info.offset); data.limit(info.offset + info.size)
                                writeSample(video, data, info)
                            }
                            codec.releaseOutputBuffer(i, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "drain failed (video=$video)", e)
                synchronized(lock) { muxFailed = true }
            }
        }

        private fun addTrack(format: MediaFormat, video: Boolean) {
            synchronized(lock) {
                if (muxStarted || muxFailed || finished) return        // e.g. audio appeared after we started without it
                val t = muxer!!.addTrack(format)
                if (video) { vTrack = t; vTrackAtMs = System.nanoTime() / 1_000_000 } else aTrack = t
                maybeStart(false)
            }
        }

        /** Starts the muxer once every expected track exists. `force` = start with whatever exists (video only). Lock held. */
        private fun maybeStart(force: Boolean) {
            if (muxStarted || muxFailed || finished || vTrack < 0) return
            val have = 1 + (if (aTrack >= 0) 1 else 0)
            if (have < tracksExpected && !force) return
            muxer!!.start(); muxStarted = true
            Log.i(TAG, "muxer started with $have track(s)" + if (have < tracksExpected) " (no audio)" else "")
            for (p in pending.sortedBy { it.pts }) writeNow(p.video, ByteBuffer.wrap(p.data), p.pts, p.flags)
            pending.clear(); pendingBytes = 0
        }

        /**
         * Audio capture can produce nothing (silent app, capture blocked by the game). Never let that cost us the video:
         * if the video track has existed for AUDIO_WAIT_MS and still no audio track, start the muxer without audio.
         */
        private fun startWithoutAudioIfStuck() {
            synchronized(lock) {
                if (muxStarted || muxFailed || finished || vTrack < 0) return
                if (System.nanoTime() / 1_000_000 - vTrackAtMs < AUDIO_WAIT_MS) return
                runCatching { maybeStart(true) }.onFailure { Log.w(TAG, "muxer start failed", it); muxFailed = true }
            }
        }

        private fun writeNow(video: Boolean, data: ByteBuffer, pts: Long, flags: Int) {
            val track = if (video) vTrack else aTrack
            if (track < 0) return
            val bi = MediaCodec.BufferInfo()
            bi.set(data.position(), data.remaining(), pts, flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM.inv())
            runCatching { muxer!!.writeSampleData(track, data, bi) }
        }

        /** Writes straight to the muxer once it has started; until then keeps a bounded copy (no blocking). */
        private fun writeSample(video: Boolean, data: ByteBuffer, info: MediaCodec.BufferInfo) {
            synchronized(lock) {
                if (muxFailed || finished) return
                if (muxStarted) { writeNow(video, data, info.presentationTimeUs, info.flags); return }
                if (!video && pendingBytes > 4 * 1024 * 1024) return     // audio only: bounded while waiting for video
                val bytes = ByteArray(info.size); data.get(bytes)
                pending.add(Pending(video, bytes, info.presentationTimeUs, info.flags)); pendingBytes += bytes.size
            }
        }

        fun abort() {
            stopping = true; finished = true
            runCatching { audioRec?.release() }
            runCatching { vCodec?.release() }
            runCatching { aCodec?.release() }
            runCatching { muxer?.release() }
        }

        /** Stops everything, writes the MP4, saves the sidecar and cuts highlight clips. */
        fun finish() {
            try { finishInner() } finally { busy.remove(file.name) }   // file stays hidden from the UI until fully done
        }

        private fun finishInner() {
            stopping = true
            runCatching { vCodec?.signalEndOfInputStream() }
            runCatching { audioRec?.stop() }
            aReadThread?.join(2000)
            vThread?.join(3000); aDrainThread?.join(3000)
            runCatching { audioRec?.release() }
            runCatching { vCodec?.stop() }; runCatching { vCodec?.release() }
            runCatching { aCodec?.stop() }; runCatching { aCodec?.release() }
            val ok = synchronized(lock) {
                if (!muxStarted && !muxFailed && vTrack >= 0) runCatching { maybeStart(true) }.onFailure { muxFailed = true }
                finished = true
                muxStarted && !muxFailed && runCatching { muxer!!.stop() }.isSuccess
            }
            Log.i(TAG, "finish ok=$ok size=${file.length()}")
            runCatching { muxer?.release() }
            val longEnough = System.currentTimeMillis() - startedAt >= 5_000
            if (!ok || !longEnough) { file.delete(); return }
            runCatching { File(file.parentFile, file.nameWithoutExtension + ".json")
                .writeText(JSONObject().put("g", game).put("k", "full").toString()) }
            if (wantHighlights) runCatching { cutHighlights() }
        }

        /** Picks the strongest moments (at least 30 s apart, max 3) and cuts a clip around each. */
        private fun cutHighlights() {
            val ms = synchronized(markers) { markers.toList() }
            if (ms.isEmpty()) return
            val picked = ArrayList<Marker>()
            for (m in ms.sortedByDescending { it.score }) {
                if (picked.size >= 3) break
                if (picked.none { abs(it.tMs - m.tMs) < 30_000 }) picked.add(m)
            }
            val total = System.currentTimeMillis() - startedAt
            picked.sortedBy { it.tMs }.forEachIndexed { n, m ->
                // OCR-based events are only known to within a screenshot interval, so look further back
                val before = if (m.reason == "manual") 20_000L else if (m.reason == "loud") 8_000L else 40_000L
                val after = if (m.reason == "manual") 10_000L else 6_000L
                val s = maxOf(0L, m.tMs - before); val e = minOf(total, m.tMs + after)
                if (e - s < 4_000) return@forEachIndexed
                val name = "hl-" + file.nameWithoutExtension + "-" + (n + 1) + ".mp4"
                val out = File(file.parentFile, "$name.part")            // hidden until complete
                val fin = File(file.parentFile, name)
                if (cut(file, out, s, e)) {
                    File(file.parentFile, fin.nameWithoutExtension + ".json").writeText(
                        JSONObject().put("g", game).put("k", "hl").put("r", m.reason).toString())
                    if (!out.renameTo(fin)) out.delete()
                } else out.delete()
            }
        }
    }
}

/** Keeps one approved screen-capture session alive (Android allows one approval per session). */
class RecService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "stop") { Recorder.shutdown { stopSelf() }; return START_NOT_STICKY }  // stay foreground until the MP4 is finalised
        if (i?.action == "mark") { Recorder.mark("manual", 10); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Recording", NotificationManager.IMPORTANCE_LOW))
        val markPi = PendingIntent.getService(this, 1, Intent(this, RecService::class.java).setAction("mark"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, "rec")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("BlockStreak recording is on")
            .setContentText("Tap Save highlight to mark a great moment")
            .addAction(Notification.Action.Builder(null, "Save highlight", markPi).build())
            .setOngoing(true).build()
        startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val code = i?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra("data", Intent::class.java) else i?.getParcelableExtra("data")
        // Android 14: a result Intent can be used once; reusing it throws SecurityException
        val p = try { if (data != null) getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data) else null }
                catch (e: SecurityException) { null }
        if (p == null) { if (!Recorder.hasProjection()) stopSelf(); return START_NOT_STICKY }
        Recorder.attach(p, this)
        return START_NOT_STICKY
    }

    override fun onDestroy() { Recorder.shutdown(); super.onDestroy() }
}

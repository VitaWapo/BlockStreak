package com.codexter.blockstreak

import android.graphics.Bitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Reads words such as "Day 12", "XP Level 30", "Biome: Plains" or "Position: 10 64 -20" from a
 * screenshot using on-device text recognition (nothing leaves the phone).
 */
object DayInfo {
    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    // OCR often mistakes 0 for O and 1 for I, l or |, so those letters are allowed inside numbers.
    private const val NUM = "([0-9OoIl|]{1,6})(?![A-Za-z0-9])"

    private val DAY = Regex("\\bday\\s*[:#.=]?\\s*$NUM", RegexOption.IGNORE_CASE)
    private val LEVEL = Regex(
        "\\b(?:xp|exp|level|lvl)(?:\\s*(?:level|lvl))?\\s*[:#.=]?\\s*$NUM",
        RegexOption.IGNORE_CASE
    )
    private val BIOME = Regex("\\bbiome\\s*[:=\\-]?\\s*([A-Za-z][A-Za-z _']{2,30})", RegexOption.IGNORE_CASE)
    private val POS = Regex(
        "\\b(?:xyz|pos|position|coords?|coordinates)\\s*[:=]?\\s*" +
            "(-?\\d{1,8})(?:\\.\\d+)?[\\s,/]+(-?\\d{1,8})(?:\\.\\d+)?[\\s,/]+(-?\\d{1,8})(?:\\.\\d+)?",
        RegexOption.IGNORE_CASE
    )

    /** Runs text recognition on the bitmap (call on a background thread) and parses the result. */
    fun read(bmp: Bitmap): JSONObject {
        val result = Tasks.await(
            recognizer.process(InputImage.fromBitmap(bmp, 0)),
            20,
            TimeUnit.SECONDS
        )
        return parse(result.text)
    }

    fun parse(raw: String): JSONObject {
        val out = JSONObject()
        val text = raw.replace('\u00A0', ' ')

        DAY.find(text)?.let { m ->
            fixNum(m.groupValues[1], 1, 999_999)?.let { out.put("day", it) }
        }
        LEVEL.find(text)?.let { m ->
            fixNum(m.groupValues[1], 0, 24_791)?.let { out.put("level", it) }
        }
        BIOME.find(text)?.let { m ->
            val name = m.groupValues[1].replace('_', ' ').replace(Regex("\\s+"), " ").trim()
            if (name.length >= 3) {
                out.put(
                    "biome",
                    name.split(' ').joinToString(" ") { w ->
                        w.lowercase().replaceFirstChar { c -> c.uppercase() }
                    }
                )
            }
        }
        POS.find(text)?.let { m ->
            val x = m.groupValues[1].toIntOrNull()
            val y = m.groupValues[2].toIntOrNull()
            val z = m.groupValues[3].toIntOrNull()
            if (x != null && y != null && z != null) {
                out.put("pos", JSONArray().put(x).put(y).put(z))
            }
        }
        return out
    }

    private fun fixNum(s: String, min: Int, max: Int): Int? {
        if (!s.any { it.isDigit() }) return null // "lol" must not become 101
        val fixed = s.map { c ->
            when (c) {
                'O', 'o' -> '0'
                'I', 'l', '|' -> '1'
                else -> c
            }
        }.joinToString("")
        val n = fixed.toIntOrNull() ?: return null
        return if (n in min..max) n else null
    }
}

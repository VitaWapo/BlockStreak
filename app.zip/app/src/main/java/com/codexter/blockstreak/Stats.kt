package com.codexter.blockstreak

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Per-game and per-hour play time, read from Android's usage events (same permission as game detection). */
object Stats {
    private val GAMES = mapOf(
        "com.mojang.minecraftpe" to "mc",
        "com.mojang.minecraftpe.preview" to "pre",
        "xyz.flarial.client" to "fl",
        "com.flarialmc.flarial_launcher" to "fl")
    private const val MAX_SPAN = 8 * 3_600_000L // ignore a "session" longer than 8 h (usually a missed close event)

    private class Acc {
        val perGame = HashMap<String, HashMap<String, Long>>() // date -> game -> ms
        val perHour = HashMap<String, LongArray>()             // date -> 24 buckets (ms)
    }

    private fun scan(c: Context, from: Long, now: Long): Acc {
        val acc = Acc()
        val usm = c.getSystemService(UsageStatsManager::class.java) ?: return acc
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val open = HashMap<String, Long>()

        fun span(game: String, s: Long, e: Long) {
            if (e <= s || e - s > MAX_SPAN) return
            var cur = s
            while (cur < e) {
                val cal = Calendar.getInstance().apply { timeInMillis = cur; set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.HOUR_OF_DAY, 1) }
                val next = minOf(e, cal.timeInMillis)
                val k = fmt.format(Date(cur)); val hour = Calendar.getInstance().apply { timeInMillis = cur }.get(Calendar.HOUR_OF_DAY)
                val d = next - cur
                acc.perGame.getOrPut(k) { HashMap() }.merge(game, d, Long::plus)
                acc.perHour.getOrPut(k) { LongArray(24) }[hour] += d
                cur = next
            }
        }

        val ev = usm.queryEvents(from, now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            val pkg = e.packageName ?: continue
            val g = GAMES[pkg] ?: continue
            when (e.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> if (!open.containsKey(pkg)) open[pkg] = e.timeStamp
                UsageEvents.Event.ACTIVITY_PAUSED -> open.remove(pkg)?.let { span(g, it, e.timeStamp) }
            }
        }
        open.forEach { (pkg, s) -> span(GAMES[pkg] ?: "mc", s, now) }
        return acc
    }

    /** {"d": {"2026-11-25": {"mc": 40, "fl": 10}}, "h": {"2026-11-25": [24 minutes]}}. Android only keeps ~a week of events. */
    fun byGame(c: Context, days: Int): String {
        val now = System.currentTimeMillis()
        val start = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.DAY_OF_YEAR, -(days.coerceIn(1, 30) - 1)) }.timeInMillis
        val acc = runCatching { scan(c, start, now) }.getOrDefault(Acc())
        val d = JSONObject(); val h = JSONObject()
        acc.perGame.forEach { (k, m) -> val o = JSONObject(); m.forEach { (g, ms) -> if (ms >= 30_000) o.put(g, Math.round(ms / 60000.0).toInt()) }; if (o.length() > 0) d.put(k, o) }
        acc.perHour.forEach { (k, a) -> val arr = JSONArray(); a.forEach { arr.put(Math.round(it / 60000.0).toInt()) }; h.put(k, arr) }
        return JSONObject().put("d", d).put("h", h).toString()
    }

    fun todayMinutes(c: Context): Int {
        val now = System.currentTimeMillis()
        val start = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        val acc = runCatching { scan(c, start, now) }.getOrDefault(Acc())
        return Math.round(acc.perGame.values.sumOf { it.values.sum() } / 60000.0).toInt()
    }

    /** True if one of the games was in the foreground in the last 10 minutes. */
    fun playedRecently(c: Context): Boolean {
        val now = System.currentTimeMillis()
        val usm = c.getSystemService(UsageStatsManager::class.java) ?: return false
        return runCatching {
            val ev = usm.queryEvents(now - 600_000L, now); val e = UsageEvents.Event()
            var seen = false
            while (ev.hasNextEvent()) { ev.getNextEvent(e); if (GAMES.containsKey(e.packageName)) seen = true }
            seen
        }.getOrDefault(false)
    }

    /** Median hour of day when the player usually starts (last ~week). Default 18. */
    fun usualHour(c: Context): Int {
        val now = System.currentTimeMillis()
        val acc = runCatching { scan(c, now - 7 * 86_400_000L, now) }.getOrDefault(Acc())
        val firsts = acc.perHour.values.mapNotNull { a -> a.indexOfFirst { it >= 120_000L }.takeIf { it >= 0 } }.sorted()
        return if (firsts.isEmpty()) 18 else firsts[firsts.size / 2]
    }
}

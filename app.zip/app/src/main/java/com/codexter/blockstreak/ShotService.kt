package com.codexter.blockstreak

import android.accessibilityservice.AccessibilityService
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.PowerManager
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.random.Random

/**
 * Notices when Minecraft is in front and, while it stays there, saves an occasional screenshot
 * (shown in the app's Auto gallery and copied to the user's folder) and runs the screen recorder.
 *
 * Window events alone are not reliable: a stray event from another app used to switch everything off for the rest
 * of the session, and nothing noticed Minecraft that was already open when the service (re)started. So when Usage
 * Access is allowed, a light watchdog asks Android every few seconds which app is in front and decides from that.
 */
class ShotService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val io: ExecutorService = Executors.newSingleThreadExecutor()
    // Recorder start/stop run here, in order, and never behind a slow OCR job on `io`.
    private val recIo: ExecutorService = Executors.newSingleThreadExecutor()
    private var playing = false
    private var kind = 'r'

    // foreground tracking from usage events
    private var fgPkg: String? = null
    private var fgFrom = 0L
    private var nullPolls = 0

    private val tick = object : Runnable {
        override fun run() {
            if (!playing) return
            capture()
            scheduleNext(false)
        }
    }

    private val watch = object : Runnable {
        override fun run() {
            try { poll() } catch (t: Throwable) { /* try again next time */ }
            handler.postDelayed(this, POLL_MS)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.removeCallbacks(watch)
        handler.postDelayed(watch, 1_500L)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        when {
            isMc(pkg) -> startPlaying(pkg)
            ignorable(pkg) -> Unit
            // With Usage Access the watchdog decides when the game was left; one stray window must not stop us.
            usageOk() -> Unit
            else -> stopPlaying()
        }
    }

    override fun onInterrupt() {
        stopPlaying()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        handler.removeCallbacks(watch)
        stopPlaying()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        handler.removeCallbacks(watch)
        stopPlaying()
        io.shutdown()
        recIo.shutdown()   // already-queued end() still runs
        super.onDestroy()
    }

    private fun isMc(pkg: String?) = pkg == "com.mojang.minecraftpe" || pkg == "com.mojang.minecraftpe.preview"

    /** Notification shade, keyboards and system dialogs do not mean Minecraft was left. */
    private fun ignorable(pkg: String) =
        pkg == "com.android.systemui" || pkg == "android" || pkg.contains("inputmethod") || pkg.contains("keyboard")

    private fun usageOk(): Boolean = try {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }

    /** The app Android says is in front, kept up to date from usage events (null = unknown / none). */
    private fun foreground(): String? {
        val um = getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return fgPkg
        val now = System.currentTimeMillis()
        val from = if (fgFrom == 0L) now - 12L * 3_600_000L else fgFrom - 5_000L   // small overlap; replaying is harmless
        val ev = um.queryEvents(from, now) ?: return fgPkg
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> fgPkg = e.packageName
                UsageEvents.Event.ACTIVITY_PAUSED -> if (e.packageName == fgPkg) fgPkg = null
            }
        }
        fgFrom = now
        return fgPkg
    }

    private fun poll() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) return
        if (!usageOk()) return
        val fg = foreground()
        if (fg == null) {
            if (playing && ++nullPolls >= 3) { nullPolls = 0; stopPlaying() }
            return
        }
        nullPolls = 0
        if (isMc(fg)) startPlaying(fg)
        else if (playing && !ignorable(fg)) stopPlaying()
    }

    private fun startPlaying(pkg: String) {
        kind = if (pkg.endsWith(".preview")) 'p' else 'r'
        if (playing) return
        playing = true
        scheduleNext(true)
        val app = applicationContext
        runCatching {
            recIo.execute {
                if (Recorder.hasProjection()) Recorder.begin(app, pkg)
                else Recorder.promptRestart(app)       // recording was on before; ask the user to approve it again
            }
        }
    }

    private fun stopPlaying() {
        playing = false
        handler.removeCallbacks(tick)
        runCatching { recIo.execute { Recorder.end() } }   // stops after a short grace period
    }

    private fun scheduleNext(first: Boolean) {
        handler.removeCallbacks(tick)
        val delay: Long = if (first) {
            Random.nextLong(10_000L, 25_000L)
        } else {
            val base = AutoShots.interval(this) * 60_000L
            (base * Random.nextDouble(0.7, 1.3)).toLong()
        }
        handler.postDelayed(tick, delay)
    }

    private fun capture() {
        if (Build.VERSION.SDK_INT < 30) return
        if (!AutoShots.enabled(this)) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) return
        // Never photograph another app: check once more that the game really is in front.
        if (usageOk()) {
            val fg = try { foreground() } catch (t: Throwable) { null }
            if (fg != null && !isMc(fg) && !ignorable(fg)) { stopPlaying(); return }
        }
        if (AutoShots.countToday(this) >= AutoShots.cap(this)) return
        val k = kind
        takeScreenshot(Display.DEFAULT_DISPLAY, io, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                val buffer = screenshot.hardwareBuffer
                try {
                    val hw = Bitmap.wrapHardwareBuffer(buffer, screenshot.colorSpace)
                    if (hw != null) {
                        val sw = hw.copy(Bitmap.Config.ARGB_8888, false)
                        hw.recycle()
                        if (sw != null) {
                            val saved = AutoShots.save(this@ShotService, sw, k)
                            if (saved != null && AutoShots.ocr(this@ShotService)) {
                                try {
                                    val info = DayInfo.read(sw)
                                    AutoShots.writeInfo(this@ShotService, saved, info)
                                    Recorder.onInfo(
                                        if (info.has("day")) info.optInt("day") else null,
                                        if (info.has("level")) info.optInt("level") else null,
                                        if (info.has("biome")) info.optString("biome") else null
                                    )
                                } catch (t: Throwable) {
                                    // text recognition failed: keep the screenshot without info
                                }
                            }
                            sw.recycle()
                        }
                    }
                } catch (e: Exception) {
                    // skip this shot
                } finally {
                    buffer.close()
                }
            }

            override fun onFailure(errorCode: Int) {
                // try again next tick
            }
        })
    }

    companion object {
        private const val POLL_MS = 8_000L
    }
}

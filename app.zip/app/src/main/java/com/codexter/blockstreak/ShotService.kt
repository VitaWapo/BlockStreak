package com.codexter.blockstreak

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.random.Random

/**
 * Notices when Minecraft comes to the front and, while it stays there, saves an occasional
 * screenshot into BlockStreak's private storage (shown in the app's Auto gallery).
 */
class ShotService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val io: ExecutorService = Executors.newSingleThreadExecutor()
    private var playing = false
    private var kind = 'r'

    private val tick = object : Runnable {
        override fun run() {
            if (!playing) return
            capture()
            scheduleNext(false)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        when {
            pkg == "com.mojang.minecraftpe" || pkg == "com.mojang.minecraftpe.preview" -> {
                kind = if (pkg.endsWith(".preview")) 'p' else 'r'
                if (!playing) {
                    playing = true
                    scheduleNext(true)
                }
            }
            // Notification shade, keyboards and similar overlays do not mean Minecraft was left.
            pkg == "com.android.systemui" ||
                pkg.contains("inputmethod") ||
                pkg.contains("keyboard") -> Unit
            else -> stopPlaying()
        }
    }

    override fun onInterrupt() {
        stopPlaying()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        stopPlaying()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        stopPlaying()
        io.shutdown()
        super.onDestroy()
    }

    private fun stopPlaying() {
        playing = false
        handler.removeCallbacks(tick)
    }

    private fun scheduleNext(first: Boolean) {
        handler.removeCallbacks(tick)
        val delay: Long = if (first) {
            Random.nextLong(20_000L, 60_000L)
        } else {
            val base = AutoShots.interval(this) * 60_000L
            (base * Random.nextDouble(0.7, 1.3)).toLong()
        }
        handler.postDelayed(tick, delay)
    }

    private fun capture() {
        if (Build.VERSION.SDK_INT < 30) return
        if (!AutoShots.enabled(this)) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) return
        if (AutoShots.countToday(this) >= AutoShots.cap(this)) return
        val k = kind
        takeScreenshot(Display.DEFAULT_DISPLAY, io, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                val buffer = screenshot.hardwareBuffer
                try {
                    val hw = Bitmap.wrapHardwareBuffer(buffer, screenshot.colorSpace)
                    if (hw != null) {
                        val sw = hw.copy(Bitmap.Config.ARGB_8888, false)
                        hw.recycle()
                        if (sw != null) {
                            val saved = AutoShots.save(this@ShotService, sw, k)
                            if (saved != null && AutoShots.ocr(this@ShotService)) {
                                try {
                                    val info = DayInfo.read(sw)
                                    AutoShots.writeInfo(this@ShotService, saved, info)
                                } catch (t: Throwable) {
                                    // text recognition failed: keep the screenshot without info
                                }
                            }
                            sw.recycle()
                        }
                    }
                } catch (e: Exception) {
                    // skip this shot
                } finally {
                    buffer.close()
                }
            }

            override fun onFailure(errorCode: Int) {
                // try again next tick
            }
        })
    }
}

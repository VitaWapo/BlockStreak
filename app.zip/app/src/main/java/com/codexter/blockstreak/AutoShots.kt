package com.codexter.blockstreak

import android.content.ComponentName
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.ZoneId
import java.util.Date
import java.util.Locale

/** Storage + settings for screenshots the app takes by itself. Files live in app-private storage. */
object AutoShots {
    private const val PREFS = "autoshots"
    private const val MAX_FILES = 400
    private const val MAX_SIDE = 1920

    // File name = <epochMs>_<r|p>_<width>x<height>.jpg   (r = Minecraft, p = Minecraft Preview)
    private val ID_RE = Regex("^\\d{10,14}_[rp]_\\d{2,5}x\\d{2,5}\\.jpg$")

    fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "autoshots")
        if (!d.exists()) d.mkdirs()
        return d
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun enabled(ctx: Context): Boolean = prefs(ctx).getBoolean("enabled", true)
    fun interval(ctx: Context): Int = prefs(ctx).getInt("interval", 5)
    fun cap(ctx: Context): Int = prefs(ctx).getInt("cap", 12)
    fun ocr(ctx: Context): Boolean = prefs(ctx).getBoolean("ocr", true)

    fun setConfig(ctx: Context, enabled: Boolean, interval: Int, cap: Int, ocr: Boolean) {
        prefs(ctx).edit()
            .putBoolean("enabled", enabled)
            .putInt("interval", interval.coerceIn(1, 60))
            .putInt("cap", cap.coerceIn(1, 100))
            .putBoolean("ocr", ocr)
            .apply()
    }

    fun serviceOn(ctx: Context): Boolean {
        val raw = Settings.Secure.getString(
            ctx.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val mine = ComponentName(ctx, ShotService::class.java)
        return raw.split(':').any { ComponentName.unflattenFromString(it) == mine }
    }

    private fun stamp(name: String): Long = name.substringBefore('_').toLong()

    private fun files(ctx: Context): List<File> {
        val all = dir(ctx).listFiles() ?: return emptyList()
        return all.filter { ID_RE.matches(it.name) }.sortedByDescending { stamp(it.name) }
    }

    fun list(ctx: Context): JSONArray {
        val arr = JSONArray()
        for (f in files(ctx)) {
            val parts = f.name.removeSuffix(".jpg").split('_')
            val wh = parts[2].split('x')
            val o = JSONObject()
                .put("id", f.name)
                .put("t", parts[0].toLong())
                .put("k", parts[1])
                .put("w", wh[0].toInt())
                .put("h", wh[1].toInt())
                .put("b", f.length())
            val side = File(dir(ctx), f.name + ".json")
            if (side.exists()) {
                try {
                    o.put("info", JSONObject(side.readText()))
                } catch (e: Exception) {
                    // unreadable info file: show the shot without it
                }
            }
            arr.put(o)
        }
        return arr
    }

    fun countToday(ctx: Context): Int {
        val zone = ZoneId.systemDefault()
        val start = LocalDate.now(zone).atStartOfDay(zone).toInstant().toEpochMilli()
        return files(ctx).count { stamp(it.name) >= start }
    }

    /** Saves the shot and returns its file name, or null if it failed. */
    fun save(ctx: Context, src: Bitmap, kind: Char): String? {
        var bmp = src
        val longest = maxOf(src.width, src.height)
        if (longest > MAX_SIDE) {
            val s = MAX_SIDE.toFloat() / longest
            bmp = Bitmap.createScaledBitmap(
                src,
                (src.width * s).toInt().coerceAtLeast(1),
                (src.height * s).toInt().coerceAtLeast(1),
                true
            )
        }
        val f = File(dir(ctx), "${System.currentTimeMillis()}_${kind}_${bmp.width}x${bmp.height}.jpg")
        return try {
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            if (bmp !== src) bmp.recycle()
            prune(ctx)
            f.name
        } catch (e: Exception) {
            f.delete()
            null
        }
    }

    /** Stores what text recognition found (day, level, biome...) next to the screenshot. */
    fun writeInfo(ctx: Context, name: String, info: JSONObject) {
        if (!ID_RE.matches(name) || info.length() == 0) return
        try {
            File(dir(ctx), name + ".json").writeText(info.toString())
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun prune(ctx: Context) {
        val all = files(ctx)
        if (all.size > MAX_FILES) {
            for (f in all.drop(MAX_FILES)) {
                f.delete()
                File(f.path + ".json").delete()
            }
        }
    }

    fun delete(ctx: Context, id: String): Boolean {
        if (!ID_RE.matches(id)) return false
        File(dir(ctx), id + ".json").delete()
        return File(dir(ctx), id).delete()
    }

    /** Copies one auto screenshot to Downloads/BlockStreak/Auto so the user can keep it. */
    fun exportToDownloads(ctx: Context, id: String): Boolean {
        if (!ID_RE.matches(id)) return false
        val src = File(dir(ctx), id)
        if (!src.exists()) return false
        val taken = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(stamp(id)))
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "BlockStreak_$taken.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(
                MediaStore.MediaColumns.RELATIVE_PATH,
                Environment.DIRECTORY_DOWNLOADS + "/BlockStreak/Auto"
            )
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: return false
        return try {
            val out = ctx.contentResolver.openOutputStream(uri)
                ?: throw IllegalStateException("no stream")
            out.use { o -> src.inputStream().use { i -> i.copyTo(o) } }
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            ctx.contentResolver.update(uri, done, null, null)
            true
        } catch (e: Exception) {
            try {
                ctx.contentResolver.delete(uri, null, null)
            } catch (e2: Exception) {
                // ignore
            }
            false
        }
    }
}

package com.codexter.blockstreak

import android.content.ComponentName
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.ZoneId
import java.util.Date
import java.util.Locale

/**
 * Storage + settings for screenshots the app takes by itself. The working copy lives in app-private storage
 * (shown in the Auto gallery). Every new shot is also copied automatically to Downloads/BlockStreak/Auto,
 * or to a folder the user picked, so it survives uninstalling the app.
 */
object AutoShots {
    private const val PREFS = "autoshots"
    private const val MAX_FILES = 400
    private const val MAX_SIDE = 1920

    // File name = <epochMs>_<r|p|u>_<width>x<height>.jpg   (r = Minecraft, p = Minecraft Preview, u = added by the user)
    private val ID_RE = Regex("^\\d{10,14}_[rpu]_\\d{2,5}x\\d{2,5}\\.jpg$")

    fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "autoshots")
        if (!d.exists()) d.mkdirs()
        return d
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun enabled(ctx: Context): Boolean = prefs(ctx).getBoolean("enabled", true)
    fun interval(ctx: Context): Int = prefs(ctx).getInt("interval", 5)
    fun cap(ctx: Context): Int = prefs(ctx).getInt("cap", 12)
    fun ocr(ctx: Context): Boolean = prefs(ctx).getBoolean("ocr", true)

    fun setConfig(ctx: Context, enabled: Boolean, interval: Int, cap: Int, ocr: Boolean) {
        prefs(ctx).edit()
            .putBoolean("enabled", enabled)
            .putInt("interval", interval.coerceIn(1, 60))
            .putInt("cap", cap.coerceIn(1, 100))
            .putBoolean("ocr", ocr)
            .apply()
    }

    fun serviceOn(ctx: Context): Boolean {
        val raw = Settings.Secure.getString(
            ctx.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val mine = ComponentName(ctx, ShotService::class.java)
        return raw.split(':').any { ComponentName.unflattenFromString(it) == mine }
    }

    private fun stamp(name: String): Long = name.substringBefore('_').toLong()

    private fun files(ctx: Context): List<File> {
        val all = dir(ctx).listFiles() ?: return emptyList()
        return all.filter { ID_RE.matches(it.name) }.sortedByDescending { stamp(it.name) }
    }

    fun list(ctx: Context): JSONArray {
        val arr = JSONArray()
        for (f in files(ctx)) {
            val parts = f.name.removeSuffix(".jpg").split('_')
            val wh = parts[2].split('x')
            val o = JSONObject()
                .put("id", f.name)
                .put("t", parts[0].toLong())
                .put("k", parts[1])
                .put("w", wh[0].toInt())
                .put("h", wh[1].toInt())
                .put("b", f.length())
            val side = File(dir(ctx), f.name + ".json")
            if (side.exists()) {
                try {
                    o.put("info", JSONObject(side.readText()))
                } catch (e: Exception) {
                    // unreadable info file: show the shot without it
                }
            }
            arr.put(o)
        }
        return arr
    }

    /** Shots the app took today. Screenshots the user added by hand do not count against the daily limit. */
    fun countToday(ctx: Context): Int {
        val zone = ZoneId.systemDefault()
        val start = LocalDate.now(zone).atStartOfDay(zone).toInstant().toEpochMilli()
        return files(ctx).count { stamp(it.name) >= start && !it.name.contains("_u_") }
    }

    /** Saves the shot, copies it to the user's folder, and returns its file name, or null if it failed. */
    fun save(ctx: Context, src: Bitmap, kind: Char): String? {
        var bmp = src
        val longest = maxOf(src.width, src.height)
        if (longest > MAX_SIDE) {
            val s = MAX_SIDE.toFloat() / longest
            bmp = Bitmap.createScaledBitmap(
                src,
                (src.width * s).toInt().coerceAtLeast(1),
                (src.height * s).toInt().coerceAtLeast(1),
                true
            )
        }
        val f = File(dir(ctx), "${System.currentTimeMillis()}_${kind}_${bmp.width}x${bmp.height}.jpg")
        val name = try {
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            if (bmp !== src) bmp.recycle()
            prune(ctx)
            f.name
        } catch (e: Exception) {
            f.delete()
            null
        }
        if (name != null) {
            try {
                mirror(ctx, name)
                retryPending(ctx, 5)
            } catch (t: Throwable) {
                // the shot is safe in the app; the copy is retried after the next shot
            }
        }
        return name
    }

    /** Adds a screenshot the user picked from their phone to the Auto gallery. */
    fun importShot(ctx: Context, jpeg: ByteArray, whenMs: Long, w: Int, h: Int): String? {
        if (jpeg.isEmpty()) return null
        val now = System.currentTimeMillis()
        var t = if (whenMs in 1_000_000_000_000L..now) whenMs else now
        val ww = w.coerceIn(10, 99999)
        val hh = h.coerceIn(10, 99999)
        var f = File(dir(ctx), "${t}_u_${ww}x${hh}.jpg")
        while (f.exists()) { t++; f = File(dir(ctx), "${t}_u_${ww}x${hh}.jpg") }
        return try {
            f.writeBytes(jpeg)
            prune(ctx)
            f.name
        } catch (e: Exception) {
            f.delete()
            null
        }
    }

    /** Stores what text recognition found (day, level, biome...) next to the screenshot. */
    fun writeInfo(ctx: Context, name: String, info: JSONObject) {
        if (!ID_RE.matches(name) || info.length() == 0) return
        try {
            File(dir(ctx), name + ".json").writeText(info.toString())
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun prune(ctx: Context) {
        val all = files(ctx)
        if (all.size > MAX_FILES) {
            for (f in all.drop(MAX_FILES)) {
                f.delete()
                File(f.path + ".json").delete()
            }
        }
    }

    fun delete(ctx: Context, id: String): Boolean {
        if (!ID_RE.matches(id)) return false
        File(dir(ctx), id + ".json").delete()
        return File(dir(ctx), id).delete()
    }

    // ------------------------------------------------------------------
    // Automatic copy to Downloads or to a folder the user chose
    // ------------------------------------------------------------------
    fun mirrorOn(ctx: Context): Boolean = prefs(ctx).getBoolean("mirror", true)

    fun setMirror(ctx: Context, on: Boolean) {
        val e = prefs(ctx).edit().putBoolean("mirror", on)
        if (on) e.putLong("mirrorSince", System.currentTimeMillis())   // only shots from now on are copied
        e.apply()
    }

    fun folderUri(ctx: Context): Uri? = prefs(ctx).getString("folder", null)?.let { Uri.parse(it) }

    /** Picks (or clears, with null) the folder. Shots taken before this moment are not copied unless asked. */
    fun setFolder(ctx: Context, uri: Uri?) {
        val e = prefs(ctx).edit()
        if (uri == null) e.remove("folder") else e.putString("folder", uri.toString())
        e.putLong("mirrorSince", System.currentTimeMillis()).remove("mirrorErr").apply()
    }

    fun folderLabel(ctx: Context): String {
        val tree = folderUri(ctx) ?: return "Downloads/BlockStreak/Auto"
        return try {
            val id = DocumentsContract.getTreeDocumentId(tree)
            val vol = id.substringBefore(':')
            val path = id.substringAfter(':', "")
            (if (vol == "primary") "Internal storage" else vol) + (if (path.isNotEmpty()) "/$path" else "")
        } catch (e: Exception) {
            "Your folder"
        }
    }

    /** False when a chosen folder is no longer writable (permission revoked or folder deleted). */
    fun folderOk(ctx: Context): Boolean {
        val tree = folderUri(ctx) ?: return true
        return ctx.contentResolver.persistedUriPermissions.any { it.uri == tree && it.isWritePermission }
    }

    fun mirrorError(ctx: Context): String = prefs(ctx).getString("mirrorErr", "") ?: ""

    private fun doneSet(ctx: Context): MutableSet<String> =
        HashSet(prefs(ctx).getStringSet("mirrored", emptySet()) ?: emptySet())

    private fun markDone(ctx: Context, id: String) {
        val s = doneSet(ctx)
        s.add(id)
        // keep the list small: only names that still exist matter
        val live = files(ctx).map { it.name }.toSet()
        prefs(ctx).edit().putStringSet("mirrored", s.filter { it in live || it == id }.toSet()).apply()
    }

    private fun mirrorName(id: String): String =
        "BlockStreak_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(stamp(id))) + ".jpg"

    /** Copies one shot to the chosen place. Returns true if it is there now. */
    @Synchronized fun mirror(ctx: Context, id: String): Boolean {
        if (!mirrorOn(ctx) || !ID_RE.matches(id)) return false
        if (id in doneSet(ctx)) return true
        val src = File(dir(ctx), id)
        if (!src.exists()) return false
        val tree = folderUri(ctx)
        val ok = if (tree != null) writeToTree(ctx, tree, src, mirrorName(id))
                 else writeToDownloads(ctx, src, mirrorName(id))
        if (ok) {
            markDone(ctx, id)
            prefs(ctx).edit().remove("mirrorErr").apply()
        } else if (tree != null) {
            prefs(ctx).edit().putString("mirrorErr", "Couldn't save to your folder. Choose it again.").apply()
        }
        return ok
    }

    /** Shots since the copy was switched on that never made it out (folder was unavailable, no space...). */
    fun pendingCount(ctx: Context): Int {
        if (!mirrorOn(ctx)) return 0
        val since = prefs(ctx).getLong("mirrorSince", 0L)
        val done = doneSet(ctx)
        return files(ctx).count { stamp(it.name) >= since && it.name !in done }
    }

    /** Retries shots that were not copied yet, newest first. */
    @Synchronized fun retryPending(ctx: Context, limit: Int): Int {
        if (!mirrorOn(ctx)) return 0
        val since = prefs(ctx).getLong("mirrorSince", 0L)
        val done = doneSet(ctx)
        var n = 0
        for (f in files(ctx)) {
            if (n >= limit) break
            if (stamp(f.name) < since || f.name in done) continue
            if (mirror(ctx, f.name)) n++ else break      // stop at the first failure (folder is probably unavailable)
        }
        return n
    }

    /** Copies every shot the app has (also older ones) to the chosen place. Returns how many were copied. */
    fun copyAll(ctx: Context): Int {
        var n = 0
        for (f in files(ctx).reversed()) { if (mirror(ctx, f.name)) n++ else if (folderUri(ctx) != null) break }
        return n
    }

    private fun writeToTree(ctx: Context, tree: Uri, src: File, name: String): Boolean {
        return try {
            val cr = ctx.contentResolver
            val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            val doc = DocumentsContract.createDocument(cr, parent, "image/jpeg", name) ?: return false
            val out = cr.openOutputStream(doc) ?: return false
            out.use { o -> src.inputStream().use { i -> i.copyTo(o) } }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun writeToDownloads(ctx: Context, src: File, name: String): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/BlockStreak/Auto")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            val out = ctx.contentResolver.openOutputStream(uri)
                ?: throw IllegalStateException("no stream")
            out.use { o -> src.inputStream().use { i -> i.copyTo(o) } }
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            ctx.contentResolver.update(uri, done, null, null)
            true
        } catch (e: Exception) {
            try {
                ctx.contentResolver.delete(uri, null, null)
            } catch (e2: Exception) {
                // ignore
            }
            false
        }
    }

    /** Copies one auto screenshot to Downloads/BlockStreak/Auto (manual button in the viewer). */
    fun exportToDownloads(ctx: Context, id: String): Boolean {
        if (!ID_RE.matches(id)) return false
        val src = File(dir(ctx), id)
        if (!src.exists()) return false
        return writeToDownloads(ctx, src, mirrorName(id))
    }
}

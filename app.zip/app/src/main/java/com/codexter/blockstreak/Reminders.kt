package com.codexter.blockstreak

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Notification
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Smart streak reminders. Two local notifications a day at most, and only when they help:
 *  - nudge: an hour after the time you usually start playing (learned from your last week), if you haven't played
 *  - last chance: 21:30, only if you have a streak of 2+ that would end at midnight
 * Nothing is sent when today's goal is met, while you're playing, during quiet hours, or if you've stopped playing
 * (no streak and no play in the last week). Everything runs on the phone.
 */
object Reminders {
    private const val NUDGE = 1
    private const val LAST = 2
    private fun p(c: Context) = c.getSharedPreferences("rem", Context.MODE_PRIVATE)

    fun hasPermission(c: Context) =
        Build.VERSION.SDK_INT < 33 || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun state(c: Context): String = JSONObject()
        .put("perm", hasPermission(c)).put("on", p(c).getBoolean("on", false))
        .put("qs", p(c).getInt("qs", 22)).put("qe", p(c).getInt("qe", 8))
        .put("hour", p(c).getInt("hour", 18)).toString()

    /** Called by the app whenever streak data or settings change. json: on, qs, qe, goal, streak, shields, done, recent. */
    fun set(c: Context, json: String) {
        val o = runCatching { JSONObject(json) }.getOrNull() ?: return
        p(c).edit()
            .putBoolean("on", o.optBoolean("on", false))
            .putInt("qs", o.optInt("qs", 22)).putInt("qe", o.optInt("qe", 8))
            .putInt("goal", o.optInt("goal", 10)).putInt("streak", o.optInt("streak", 0))
            .putInt("shields", o.optInt("shields", 0)).putString("done", o.optString("done", ""))
            .putBoolean("recent", o.optBoolean("recent", false)).apply()
        Thread { p(c).edit().putInt("hour", runCatching { Stats.usualHour(c) }.getOrDefault(18)).apply(); schedule(c) }.start()
    }

    private fun pi(c: Context, kind: Int) = PendingIntent.getBroadcast(c, kind,
        Intent(c, RemindReceiver::class.java).putExtra("k", kind), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun next(h: Int, m: Int): Long {
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        if (cal.timeInMillis <= System.currentTimeMillis() + 60_000L) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java) ?: return
        am.cancel(pi(c, NUDGE)); am.cancel(pi(c, LAST))
        if (!p(c).getBoolean("on", false)) return
        val nudgeH = (p(c).getInt("hour", 18) + 1).coerceIn(12, 21)
        am.setAndAllowWhileIdle(AlarmManager.RTC, next(nudgeH, 0), pi(c, NUDGE))
        am.setAndAllowWhileIdle(AlarmManager.RTC, next(21, 30), pi(c, LAST))
    }

    private fun quiet(c: Context): Boolean {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY); val s = p(c).getInt("qs", 22); val e = p(c).getInt("qe", 8)
        if (s == e) return false
        return if (s < e) h in s until e else h >= s || h < e
    }

    fun fire(c: Context, kind: Int) {
        val pr = p(c)
        if (!pr.getBoolean("on", false) || !hasPermission(c) || quiet(c)) return
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        if (pr.getString("done", "") == today) return
        val goal = pr.getInt("goal", 10); val streak = pr.getInt("streak", 0); val shields = pr.getInt("shields", 0)
        if (streak == 0 && !pr.getBoolean("recent", false)) return          // don't nag someone who has stopped
        if (Stats.playedRecently(c)) return                                   // already in the game
        val mins = Stats.todayMinutes(c)
        if (mins >= goal) return
        val left = (goal - mins).coerceAtLeast(1)
        val (title, text) = when {
            kind == LAST && streak >= 2 ->
                if (shields > 0) "Your $streak-day streak ends tonight" to "A shield would cover it, but $left min of Minecraft saves it for free."
                else "Your $streak-day streak ends at midnight" to "$left more minute${if (left == 1) "" else "s"} of Minecraft keeps it alive."
            kind == LAST -> return
            streak > 0 -> "Keep your $streak-day streak going" to "$left min of Minecraft or Flarial today is all it takes."
            else -> "Ready for a session?" to "Play $goal minutes to start a new streak."
        }
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("remind", "Streak reminders", NotificationManager.IMPORTANCE_DEFAULT))
        val open = c.packageManager.getLaunchIntentForPackage(c.packageName)?.let {
            PendingIntent.getActivity(c, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT) }
        val n = Notification.Builder(c, "remind").setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title).setContentText(text).setAutoCancel(true).setContentIntent(open).build()
        nm.notify(100 + kind, n)
    }
}

class RemindReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val pending = goAsync()
        val kind = i.getIntExtra("k", 0)
        Thread {
            try { Reminders.fire(c, kind); Reminders.schedule(c) } finally { pending.finish() }
        }.start()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { if (i.action == Intent.ACTION_BOOT_COMPLETED) Reminders.schedule(c) }
}

package com.codexter.blockstreak

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Process
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.OutputStream
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class MainActivity : ComponentActivity() {

    private lateinit var root: FrameLayout
    private lateinit var webView: WebView

    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val chooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val cb = fileCallback
            fileCallback = null
            cb?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            )
        }

    // State for the beginSave / appendSave / endSave bridge.
    private var saveUri: Uri? = null
    private var saveStream: OutputStream? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#0F151C"))
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        val assetsHandler = WebViewAssetLoader.AssetsPathHandler(this)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler(
                "/autoshots/",
                WebViewAssetLoader.InternalStoragePathHandler(this, AutoShots.dir(this))
            )
            .addPathHandler("/assets/") { path ->
                val r = assetsHandler.handle(path)
                if (r != null && path.endsWith(".woff2")) {
                    WebResourceResponse("font/woff2", null, r.data)
                } else if (r != null && path.endsWith(".ogg")) {
                    WebResourceResponse("audio/ogg", null, r.data)
                } else {
                    r
                }
            }
            .build()

        webView = WebView(this)
        webView.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        webView.setBackgroundColor(Color.parseColor("#0F151C"))
        webView.overScrollMode = WebView.OVER_SCROLL_NEVER

        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = true
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.textZoom = 100
        s.mediaPlaybackRequiresUserGesture = false

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val url = request.url
                if (url.host == WebViewAssetLoader.DEFAULT_DOMAIN) return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, url))
                } catch (e: ActivityNotFoundException) {
                    // ignore
                }
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                if (filePathCallback == null || fileChooserParams == null) return false
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    chooserLauncher.launch(fileChooserParams.createIntent())
                    true
                } catch (e: ActivityNotFoundException) {
                    fileCallback = null
                    filePathCallback.onReceiveValue(null)
                    false
                }
            }
        }

        webView.addJavascriptInterface(Bridge(), "Native")

        root.addView(webView)
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })

        if (savedInstanceState == null) {
            webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
        } else {
            if (webView.restoreState(savedInstanceState) == null) {
                webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        webView.evaluateJavascript(
            "if(window.onNativeResume){window.onNativeResume();}",
            null
        )
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        abortSave()
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        root.removeAllViews()
        webView.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------------------
    // JavaScript bridge (window.Native)
    // ------------------------------------------------------------------
    private inner class Bridge {

        @JavascriptInterface
        fun hasUsageAccess(): Boolean = checkUsageAccess()

        @JavascriptInterface
        fun openUsageSettings() {
            runOnUiThread {
                try {
                    val i = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                    i.data = Uri.parse("package:$packageName")
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                } catch (e: Exception) {
                    try {
                        val i2 = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                        i2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i2)
                    } catch (e2: Exception) {
                        // nothing else we can do
                    }
                }
            }
        }

        @JavascriptInterface
        fun minecraftInstalled(): Boolean = isMinecraftInstalled()

        @JavascriptInterface
        fun autoCfg(): String = JSONObject()
            .put("supported", android.os.Build.VERSION.SDK_INT >= 30)
            .put("serviceOn", AutoShots.serviceOn(this@MainActivity))
            .put("enabled", AutoShots.enabled(this@MainActivity))
            .put("interval", AutoShots.interval(this@MainActivity))
            .put("cap", AutoShots.cap(this@MainActivity))
            .put("ocr", AutoShots.ocr(this@MainActivity))
            .toString()

        @JavascriptInterface
        fun setAutoCfg(enabled: Boolean, interval: Int, cap: Int, ocr: Boolean) {
            AutoShots.setConfig(this@MainActivity, enabled, interval, cap, ocr)
        }

        @JavascriptInterface
        fun openAccessibilitySettings() {
            runOnUiThread {
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (e: Exception) {
                    // ignore
                }
            }
        }

        @JavascriptInterface
        fun listAutoShots(): String =
            try {
                AutoShots.list(this@MainActivity).toString()
            } catch (e: Exception) {
                "[]"
            }

        @JavascriptInterface
        fun deleteAutoShot(id: String): Boolean = AutoShots.delete(this@MainActivity, id)

        @JavascriptInterface
        fun saveAutoShot(id: String): Boolean = AutoShots.exportToDownloads(this@MainActivity, id)

        @JavascriptInterface
        fun playedMinutes(days: Int): String {
            return try {
                computePlayedMinutes(days)
            } catch (e: Exception) {
                "{}"
            }
        }

        @Suppress("DEPRECATION")
        @JavascriptInterface
        fun setBars(colorHex: String, darkIcons: Boolean) {
            runOnUiThread {
                try {
                    val c = Color.parseColor(colorHex)
                    window.statusBarColor = c
                    window.navigationBarColor = c
                    root.setBackgroundColor(c)
                    webView.setBackgroundColor(c)
                    val ctrl = WindowCompat.getInsetsController(window, window.decorView)
                    ctrl.isAppearanceLightStatusBars = darkIcons
                    ctrl.isAppearanceLightNavigationBars = darkIcons
                } catch (e: Exception) {
                    // bad colour string: ignore
                }
            }
        }

        @JavascriptInterface
        @Synchronized
        fun beginSave(name: String, mime: String): Boolean {
            abortSave()
            return try {
                val safeName = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "file" }
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
                    put(
                        MediaStore.MediaColumns.MIME_TYPE,
                        if (mime.isBlank()) "application/octet-stream" else mime
                    )
                    put(
                        MediaStore.MediaColumns.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/BlockStreak"
                    )
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return false
                val stream = contentResolver.openOutputStream(uri)
                if (stream == null) {
                    contentResolver.delete(uri, null, null)
                    return false
                }
                saveUri = uri
                saveStream = stream
                true
            } catch (e: Exception) {
                abortSave()
                false
            }
        }

        @JavascriptInterface
        @Synchronized
        fun appendSave(base64Chunk: String): Boolean {
            val stream = saveStream ?: return false
            return try {
                stream.write(Base64.decode(base64Chunk, Base64.DEFAULT))
                true
            } catch (e: Exception) {
                abortSave()
                false
            }
        }

        @JavascriptInterface
        @Synchronized
        fun endSave(): Boolean {
            val stream = saveStream
            val uri = saveUri
            if (stream == null || uri == null) return false
            return try {
                stream.flush()
                stream.close()
                saveStream = null
                saveUri = null
                val done = ContentValues().apply {
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                }
                contentResolver.update(uri, done, null, null)
                true
            } catch (e: Exception) {
                abortSave()
                false
            }
        }
    }

    @Synchronized
    private fun abortSave() {
        try {
            saveStream?.close()
        } catch (e: Exception) {
            // ignore
        }
        val uri = saveUri
        if (uri != null) {
            try {
                contentResolver.delete(uri, null, null)
            } catch (e: Exception) {
                // ignore
            }
        }
        saveStream = null
        saveUri = null
    }

    // ------------------------------------------------------------------
    // Usage Access + Minecraft play time
    // ------------------------------------------------------------------
    private fun checkUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    @Suppress("DEPRECATION")
    private fun isMinecraftInstalled(): Boolean {
        for (pkg in MINECRAFT_PACKAGES) {
            try {
                packageManager.getPackageInfo(pkg, 0)
                return true
            } catch (e: Exception) {
                // not installed, try next
            }
        }
        return false
    }

    /**
     * Returns JSON like {"2026-11-25":42,"2026-11-26":7} with minutes of Minecraft
     * foreground time per local calendar day, for the last [days] days (including today).
     */
    private fun computePlayedMinutes(days: Int): String {
        if (!checkUsageAccess()) return "{}"

        val n = days.coerceIn(1, 30)
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        val firstDay = today.minusDays((n - 1).toLong())
        val startMs = firstDay.atStartOfDay(zone).toInstant().toEpochMilli()
        val nowMs = System.currentTimeMillis()

        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        // Look back one extra day so a session already open at the start is still paired.
        val events = usm.queryEvents(startMs - DAY_MS, nowMs)
        val ev = UsageEvents.Event()

        val openSince = HashMap<String, Long>()
        val intervals = ArrayList<LongArray>()

        while (events.hasNextEvent()) {
            events.getNextEvent(ev)
            val pkg = ev.packageName ?: continue
            if (!MINECRAFT_PACKAGES.contains(pkg)) continue
            val key = pkg + "/" + (ev.className ?: "")
            when (ev.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> {
                    openSince[key] = ev.timeStamp
                }
                UsageEvents.Event.ACTIVITY_PAUSED -> {
                    val begin = openSince.remove(key)
                    if (begin != null && ev.timeStamp > begin) {
                        intervals.add(longArrayOf(begin, ev.timeStamp))
                    }
                }
            }
        }
        // Sessions still open right now.
        for (begin in openSince.values) {
            if (nowMs > begin) intervals.add(longArrayOf(begin, nowMs))
        }

        // Merge overlapping intervals so activity hand-offs are not counted twice.
        intervals.sortBy { it[0] }
        val merged = ArrayList<LongArray>()
        for (iv in intervals) {
            val last = if (merged.isEmpty()) null else merged[merged.size - 1]
            if (last != null && iv[0] <= last[1]) {
                if (iv[1] > last[1]) last[1] = iv[1]
            } else {
                merged.add(longArrayOf(iv[0], iv[1]))
            }
        }

        // Split every interval at local midnights and add it to the right day.
        val perDay = HashMap<LocalDate, Long>()
        for (iv in merged) {
            var cur = if (iv[0] < startMs) startMs else iv[0]
            val end = iv[1]
            while (cur < end) {
                val day = Instant.ofEpochMilli(cur).atZone(zone).toLocalDate()
                val nextMidnight = day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
                val segEnd = if (end < nextMidnight) end else nextMidnight
                perDay[day] = (perDay[day] ?: 0L) + (segEnd - cur)
                cur = segEnd
            }
        }

        val out = JSONObject()
        for (i in 0 until n) {
            val d = firstDay.plusDays(i.toLong())
            val ms = perDay[d] ?: 0L
            val minutes = ((ms + 30_000L) / 60_000L).toInt().coerceAtMost(1440)
            if (minutes > 0) out.put(d.toString(), minutes)
        }
        return out.toString()
    }

    companion object {
        private const val DAY_MS = 24L * 60L * 60L * 1000L
        private val MINECRAFT_PACKAGES = setOf(
            "com.mojang.minecraftpe",
            "com.mojang.minecraftpe.preview"
        )
    }
}
